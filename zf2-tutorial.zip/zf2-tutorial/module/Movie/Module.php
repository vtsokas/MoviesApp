<?php
namespace Movie;

//  use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
//  use Zend\ModuleManager\Feature\ConfigProviderInterface;
//  use Movie\Model\Movie;
//  use Movie\Model\MovieTable;
//  use Zend\Db\ResultSet\ResultSet;
//  use Zend\Db\TableGateway\TableGateway;


//  class Module implements AutoloaderProviderInterface, ConfigProviderInterface
//  {
//      public function getAutoloaderConfig()
//      {
//          return array(
//              'Zend\Loader\ClassMapAutoloader' => array(
//                 // __DIR__ . '/autoload_classmap.php',
//              ),
//              'Zend\Loader\StandardAutoloader' => array(
//                  'namespaces' => array(
//                      __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
//                  ),
//              ),
//          );
//      }

//      public function getConfig()
//      {
//          return include __DIR__ . '/config/module.config.php';
//      }

//      public function getServiceConfig()
//      {
//          return array(
//              'factories' => array(
//                  'Movie\Model\MovieTable' =>  function($sm) {
//                      $tableGateway = $sm->get('MovieTableGateway');
//                      $table = new MovieTable($tableGateway);
//                      return $table;
//                  },
//                  'MovieTableGateway' => function ($sm) {
//                      $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
//                      $resultSetPrototype = new ResultSet();
//                      $resultSetPrototype->setArrayObjectPrototype(new Movie());
//                      return new TableGateway('movie', $dbAdapter, null, $resultSetPrototype);
//                  }
//              ),
//          );
//      }
//  }
use Zend\Db\Adapter\Adapter;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\ModuleManager\Feature\ConfigProviderInterface;

class Module implements ConfigProviderInterface
{
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
            // __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return [
            'factories' => [
                Model\MovieTable::class => function ($container) {
                    $tableGateway = $container->get('Model\MovieTableGateway');

                    return new Model\MovieTable($tableGateway);
                },
                'Model\MovieTableGateway' => function ($container) {
                    $dbAdapter          = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Movie());

                    return new TableGateway('movies', $dbAdapter, null, $resultSetPrototype);
                },
            ],
        ];
    }

    public function getControllerConfig()
    {
        return [
            'factories' => [
                Controller\MovieController::class => function ($container) {
                    return new Controller\MovieController(
                        $container->get(Model\MovieTable::class)
                    );
                },
            ],
        ];
    }
}